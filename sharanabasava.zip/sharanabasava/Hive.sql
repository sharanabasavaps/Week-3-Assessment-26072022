HIVE
create table posts (id int, post_type int, creation_date string, score int, viewcount float, owneruser_id int,title string, answercount int, commentcount int ) row format delimited fields terminated by ',';
describe posts;
load data  inpath '/user/pig/posts.csv' into table posts;
select * from posts;
select Count(*) from posts;

create table comments (id int, userid int) row format delimited fields terminated by ',';
describe comments;
load data  inpath '/user/pig/comments.csv' into table comments;
select * from comments;
select Count(*) from comments;

 
create table users (id int,reputation int,display_name string,loc string,age int) row format delimited fields terminated by ',';
describe users;
load data  inpath '/user/pig/users.csv' into table users;
select * from users;
select Count(*) from users;

create table posttypes (id int, name string) row format delimited fields terminated by ',';
describe posttypes;
load data inpath '/user/pig/posttypes.csv' into table posttypes;
select * from posttypes;
select Count(*) from posttypes;

//A. Find the display name and no. of posts created by the user who has got maximum reputation.
> selct display_name,count(*) as total,reputation from posts join users on(post.id=user.id) group by display_name,reputation order by reputation desc limit 1;

//B. Find the average age of users on the Stack Overflow site.
> select avg(users.age) as A from users group by age;

//C. Find the display name of user who posted the oldest post on Stack Overflow (in terms of date).
> select display_name,creation_date from users inner join posts on (users.id=posts.id) order by creation_date asc limit 5;

//D. Find the display name and no. of comments done by the user who has got maximum reputation.
> select display_name,commentcount,reputation from users inner join posts on (posts.id=users.id) order by reputation desc limit 5;


//E. Find the display name of user who has created maximum no. of posts on Stack Overflow.
> select display_name from users inner join posts on (posts.id=users.id) order by (answercount+commentcount) desc limit 5;

//F. Find the owner name and id of user whose post has got maximum no. of view counts so far.
> select owneruser_id,display_name,viewcount from users inner join posts on (posts.id=users.id) order by viewcount desc limit 5;

//G. Find the title and owner name of the post which has maximum Find the title and owner name of post who has got maximum no. of Comment count.
> select title,owneruser_id,display_name,commentcount from users inner join posts on (posts.id=users.id) order by commentcount desc limit 1;


//H. Find the location which has maximum no of Stack Overflow users.
> select loc ,count(id) as B from users group by loc order by B desc limit 1;


//I. Find the total no. of answers, posts, comments created by Indian users.
> select loc, count(post_type) from users inner join posts on (posts.id=users.id) where loc like '%India%' group by loc;
> select loc, count(answercount) from users inner join posts on (posts.id=users.id) where loc like '%India%' group by loc;



